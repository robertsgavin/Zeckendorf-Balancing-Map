#!/usr/bin/env python3
"""
01_extended_bases.py
--------------------
Test the balancing map on additional classical linear recurrences:
  - Higher-order k-bonacci (k=5..8)
  - Lucas numbers
  - A few other fixed-coefficient families (including some that straddle α=2)
  - Selected Pisot and non-Pisot examples

Pure Python, exact integer arithmetic.  No external libraries.
"""

import math
import random
from typing import List, Tuple, Callable, Dict

# ---------------------------------------------------------------------------
# Core utilities (identical to the verified script)
# ---------------------------------------------------------------------------

def value(v: List[int], weights: List[int]) -> int:
    return sum(a * b for a, b in zip(v, weights))

def greedy(d: int, weights: List[int]) -> List[int]:
    n = len(weights)
    v = [0] * n
    remainder = d
    for i in range(n - 1, -1, -1):
        if weights[i] <= remainder:
            v[i] = 1
            remainder -= weights[i]
    return v

def max_config(k: int, n: int) -> List[int]:
    v = [0] * n
    for i in range(max(0, n - k), n):
        v[i] = 1
    return v

def min_config(k: int, n: int) -> List[int]:
    v = [0] * n
    for i in range(min(k, n)):
        v[i] = 1
    return v

def balancing_map(v: List[int], weights: List[int]) -> List[int]:
    n = len(v)
    k = sum(v)
    d = value(max_config(k, n), weights) - value(min_config(k, n), weights)
    return greedy(d, weights)

def is_exact_fixed_point(v: List[int], weights: List[int]) -> bool:
    return balancing_map(v, weights) == v

def candidate_fixed_point(n: int, weights: List[int]) -> List[int]:
    k = n // 2
    d = value(max_config(k, n), weights) - value(min_config(k, n), weights)
    return greedy(d, weights)

def find_fixed_point_by_iteration(initial: List[int], weights: List[int],
                                  max_steps: int = 80) -> Tuple[List[int], int]:
    v = initial[:]
    for step in range(max_steps):
        nxt = balancing_map(v, weights)
        if nxt == v:
            return v, step
        v = nxt
    return v, max_steps

def dominant_root_estimate(weights: List[int]) -> float:
    if len(weights) < 2:
        return 1.0
    return weights[-1] / weights[-2]

# ---------------------------------------------------------------------------
# New bases
# ---------------------------------------------------------------------------

def k_bonacci_basis(n: int, k: int) -> Tuple[List[int], int]:
    """k-bonacci: each term is sum of previous k terms.
    Initial conditions chosen so sequence is strictly increasing positive.
    """
    if n == 0:
        return [], 0
    G = [0] * (n + k + 1)
    # Standard initialisation: G_1=1, then powers of 2 until order k
    G[1] = 1
    for i in range(2, k + 1):
        G[i] = 1 << (i - 1)          # 1,2,4,8,...
    for i in range(k + 1, n + k + 1):
        G[i] = sum(G[i - j] for j in range(1, k + 1))
    weights = [G[i + 1] for i in range(n)]
    return weights, G[n]

def lucas_basis(n: int) -> Tuple[List[int], int]:
    """Lucas numbers: L_1=1, L_2=3, L_i = L_{i-1}+L_{i-2} (shifted to be increasing)."""
    if n == 0:
        return [], 0
    L = [0] * (n + 3)
    L[1], L[2] = 1, 3
    for i in range(3, n + 3):
        L[i] = L[i - 1] + L[i - 2]
    weights = [L[i + 1] for i in range(n)]
    return weights, L[n]

def recurrence_basis(n: int, coeffs: List[int], init: List[int]) -> Tuple[List[int], int]:
    """Generic linear recurrence with given coefficients and initial conditions."""
    r = len(coeffs)
    assert len(init) == r
    if n == 0:
        return [], 0
    G = [0] * (n + r + 1)
    for i in range(r):
        G[i + 1] = init[i]
    for i in range(r + 1, n + r + 1):
        G[i] = sum(coeffs[j] * G[i - 1 - j] for j in range(r))
    weights = [G[i + 1] for i in range(n)]
    return weights, G[n]

# Concrete families
def silver_ratio_basis(n: int):
    """G_i = 2 G_{i-1} + G_{i-2}  (α = 1+√2 ≈ 2.414) – already Pell, kept for completeness."""
    return recurrence_basis(n, [2, 1], [1, 2])

def plastic_companion(n: int):
    """Another order-3 sequence with plastic-number root."""
    return recurrence_basis(n, [0, 1, 1], [1, 1, 1])   # same as Padovan essentially

def non_pisot_example(n: int):
    """G_i = 3 G_{i-1} - G_{i-2}  (root ≈ 2.618, not Pisot)."""
    return recurrence_basis(n, [3, -1], [1, 3])

def high_growth(n: int):
    """G_i = 4 G_{i-1} + G_{i-2}  (α ≈ 4.236)."""
    return recurrence_basis(n, [4, 1], [1, 4])

# ---------------------------------------------------------------------------
# Experiment runner
# ---------------------------------------------------------------------------

def run_one_basis(name: str, gen: Callable, n_list: List[int],
                  num_random: int = 8, seed: int = 42):
    random.seed(seed)
    print(f"\n{'='*72}")
    print(f"Basis: {name}")
    print('='*72)

    for n in n_list:
        weights, last_w = gen(n)
        if last_w <= 0 or any(w <= 0 for w in weights):
            print(f"  n={n}: sequence not strictly positive – skipped")
            continue
        alpha = dominant_root_estimate(weights)
        high = alpha / (alpha - 1) if alpha > 1 else float('nan')
        low  = 1 / (alpha - 1) if alpha > 1 else float('nan')
        regime = ">2" if alpha > 2 else "<2"

        # Candidate
        v_cand = candidate_fixed_point(n, weights)
        val_cand = value(v_cand, weights)
        ratio_cand = val_cand / last_w
        exact = is_exact_fixed_point(v_cand, weights)

        # Dominant attractor from a few starts
        starts = [[0]*n, [1]*n]
        for _ in range(num_random):
            starts.append([random.randint(0, 1) for _ in range(n)])
        counts: Dict[int, int] = {}
        for s in starts:
            fp, _ = find_fixed_point_by_iteration(s, weights)
            counts[value(fp, weights)] = counts.get(value(fp, weights), 0) + 1
        dom_val = max(counts, key=counts.get)
        ratio_dom = dom_val / last_w

        print(f"  n={n:4d}  α≈{alpha:.8f} ({regime})  "
              f"cand_ratio={ratio_cand:.10f}  exact={exact}  "
              f"dom_ratio={ratio_dom:.10f}  "
              f"(high={high:.8f}, low={low:.8f})")

def main():
    n_list = [20, 50, 100, 200, 500]

    bases = [
        ("5-bonacci",               lambda n: k_bonacci_basis(n, 5)),
        ("6-bonacci",               lambda n: k_bonacci_basis(n, 6)),
        ("7-bonacci",               lambda n: k_bonacci_basis(n, 7)),
        ("8-bonacci",               lambda n: k_bonacci_basis(n, 8)),
        ("Lucas",                   lucas_basis),
        ("G_i=2G_{i-1}+G_{i-2}",    silver_ratio_basis),
        ("G_i=3G_{i-1}-G_{i-2}",    non_pisot_example),
        ("G_i=4G_{i-1}+G_{i-2}",    high_growth),
    ]

    print("EXTENDED BASES – balancing map survey")
    for name, gen in bases:
        run_one_basis(name, gen, n_list)

    print("\nDone.")

if __name__ == "__main__":
    main()
