#!/usr/bin/env python3
"""
05_non_greedy.py
----------------
Replace the greedy expansion by a *lazy* expansion (smallest-first)
and by a simple dual expansion.  The balancing map is otherwise unchanged.
We watch whether convergence still occurs and whether the same limiting
ratios appear.
"""

from typing import List, Tuple
import random

def value(v, w): return sum(a*b for a,b in zip(v,w))

def greedy(d, weights):
    """Classic largest-first."""
    n = len(weights)
    v = [0]*n
    for i in range(n-1, -1, -1):
        if weights[i] <= d:
            v[i] = 1
            d -= weights[i]
    return v

def lazy(d, weights):
    """Smallest-first (lazy) expansion."""
    n = len(weights)
    v = [0]*n
    for i in range(n):
        if weights[i] <= d:
            v[i] = 1
            d -= weights[i]
    return v

def dual_expansion(d, weights):
    """A simple dual: take the greedy expansion of (total_sum - d) and complement."""
    total = sum(weights)
    if d > total:
        d = total
    g = greedy(total - d, weights)
    return [1 - b for b in g]

def max_config(k, n):
    v = [0]*n
    for i in range(max(0, n-k), n): v[i] = 1
    return v

def min_config(k, n):
    v = [0]*n
    for i in range(min(k, n)): v[i] = 1
    return v

def make_map(expansion_fn):
    def phi(v, weights):
        k = sum(v)
        d = value(max_config(k, len(v)), weights) - value(min_config(k, len(v)), weights)
        return expansion_fn(d, weights)
    return phi

def iterate(start, weights, phi, max_steps=80):
    v = start[:]
    for s in range(max_steps):
        nxt = phi(v, weights)
        if nxt == v:
            return v, s
        v = nxt
    return v, max_steps

# Bases
def fibonacci(n):
    F=[0]*(n+3); F[1],F[2]=1,2
    for i in range(3,n+3): F[i]=F[i-1]+F[i-2]
    return [F[i+1] for i in range(n)], F[n]

def pell(n):
    P=[0]*(n+3); P[1],P[2]=1,2
    for i in range(3,n+3): P[i]=2*P[i-1]+P[i-2]
    return [P[i+1] for i in range(n)], P[n]

def run_comparison(name, gen, n, expansion_names_fns, num_random=6):
    weights, last = gen(n)
    alpha = weights[-1]/weights[-2]
    print(f"\n{name}  n={n}  α≈{alpha:.6f}")
    print(f"{'expansion':<12}  {'cand_ratio':>12}  {'dom_ratio':>12}  {'steps_avg':>9}")

    for ename, efn in expansion_names_fns:
        phi = make_map(efn)
        # candidate under this expansion
        k = n//2
        d = value(max_config(k,n),weights) - value(min_config(k,n),weights)
        vc = efn(d, weights)
        rc = value(vc, weights)/last

        random.seed(42)
        starts = [[0]*n, [1]*n] + [[random.randint(0,1) for _ in range(n)] for _ in range(num_random)]
        ratios, steps = [], []
        for s in starts:
            fp, st = iterate(s, weights, phi)
            ratios.append(value(fp, weights)/last)
            steps.append(st)
        from collections import Counter
        dom = max(Counter(round(r,10) for r in ratios), key=Counter(round(r,10) for r in ratios).get)
        print(f"{ename:<12}  {rc:12.8f}  {dom:12.8f}  {sum(steps)/len(steps):9.1f}")

def main():
    expansions = [
        ("greedy", greedy),
        ("lazy",   lazy),
        ("dual",   dual_expansion),
    ]
    for name, gen in [("Fibonacci", fibonacci), ("Pell", pell)]:
        for n in [40, 80, 160]:
            run_comparison(name, gen, n, expansions)
    print("\nDone.")

if __name__ == "__main__":
    main()
