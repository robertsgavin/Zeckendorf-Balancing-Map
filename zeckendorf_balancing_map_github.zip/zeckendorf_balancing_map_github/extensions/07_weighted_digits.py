#!/usr/bin/env python3
"""
07_weighted_digits.py
---------------------
Generalise from binary digits {0,1} to digits in {0,1,...,D}.
The “weight” of a string is now the sum of its digits.
Maximal / minimal configurations of a given weight are still well-defined
(place as much mass as possible on the highest / lowest positions).
The balancing map uses the same difference-of-extremal-values idea.
"""

from typing import List, Tuple
import random

def value(v: List[int], weights: List[int]) -> int:
    return sum(a*b for a,b in zip(v, weights))

def greedy_digit(d: int, weights: List[int], D: int) -> List[int]:
    """Greedy expansion allowing digits 0..D."""
    n = len(weights)
    v = [0]*n
    for i in range(n-1, -1, -1):
        # how many times can we take weights[i]?
        take = min(D, d // weights[i])
        v[i] = take
        d -= take * weights[i]
    return v

def max_config(weight: int, n: int, D: int) -> List[int]:
    """Put as much mass as possible on the highest positions."""
    v = [0]*n
    remaining = weight
    for i in range(n-1, -1, -1):
        take = min(D, remaining)
        v[i] = take
        remaining -= take
        if remaining == 0:
            break
    return v

def min_config(weight: int, n: int, D: int) -> List[int]:
    """Put as much mass as possible on the lowest positions."""
    v = [0]*n
    remaining = weight
    for i in range(n):
        take = min(D, remaining)
        v[i] = take
        remaining -= take
        if remaining == 0:
            break
    return v

def balancing_map(v: List[int], weights: List[int], D: int) -> List[int]:
    wsum = sum(v)
    d = value(max_config(wsum, len(v), D), weights) - value(min_config(wsum, len(v), D), weights)
    return greedy_digit(d, weights, D)

def iterate(start, weights, D, max_steps=60):
    v = start[:]
    for s in range(max_steps):
        nxt = balancing_map(v, weights, D)
        if nxt == v:
            return v, s
        v = nxt
    return v, max_steps

# Bases (same as before)
def fibonacci(n):
    F=[0]*(n+3); F[1],F[2]=1,2
    for i in range(3,n+3): F[i]=F[i-1]+F[i-2]
    return [F[i+1] for i in range(n)], F[n]

def pell(n):
    P=[0]*(n+3); P[1],P[2]=1,2
    for i in range(3,n+3): P[i]=2*P[i-1]+P[i-2]
    return [P[i+1] for i in range(n)], P[n]

def run(name, gen, n, D_values, num_random=5):
    weights, last = gen(n)
    alpha = weights[-1]/weights[-2]
    print(f"\n{name}  n={n}  α≈{alpha:.6f}")
    for D in D_values:
        # candidate: total weight ≈ (D*n)/2
        target_w = (D * n) // 2
        d = value(max_config(target_w, n, D), weights) - value(min_config(target_w, n, D), weights)
        vc = greedy_digit(d, weights, D)
        rc = value(vc, weights) / last

        random.seed(42)
        starts = []
        for _ in range(num_random):
            starts.append([random.randint(0, D) for _ in range(n)])
        ratios = []
        for s in starts:
            fp, _ = iterate(s, weights, D)
            ratios.append(round(value(fp, weights)/last, 10))
        from collections import Counter
        dom = Counter(ratios).most_common(1)[0][0]
        print(f"  D={D}  cand_ratio={rc:.8f}  dom_ratio={dom:.8f}")

def main():
    for name, gen in [("Fibonacci", fibonacci), ("Pell", pell)]:
        run(name, gen, n=40, D_values=[1, 2, 3, 5])
    print("\nDone.")

if __name__ == "__main__":
    main()
