#!/usr/bin/env python3
"""
02_density_scan.py
------------------
Systematically scan weight densities ρ = k/n.
For each k, compute the greedy expansion of d(k) = val(M_k) - val(m_k)
and record:
  - whether the resulting string has the same weight k (exact weight-fixed point)
  - the normalised value of that string
  - the basin size when starting from random strings of weight k (optional)

This probes the self-consistent fixed-point equation for every density,
not just ρ ≈ 1/2.
"""

import random
from typing import List, Tuple, Dict

def value(v: List[int], weights: List[int]) -> int:
    return sum(a * b for a, b in zip(v, weights))

def greedy(d: int, weights: List[int]) -> List[int]:
    n = len(weights)
    v = [0] * n
    rem = d
    for i in range(n-1, -1, -1):
        if weights[i] <= rem:
            v[i] = 1
            rem -= weights[i]
    return v

def max_config(k: int, n: int) -> List[int]:
    v = [0]*n
    for i in range(max(0, n-k), n):
        v[i] = 1
    return v

def min_config(k: int, n: int) -> List[int]:
    v = [0]*n
    for i in range(min(k, n)):
        v[i] = 1
    return v

def d_of_k(k: int, n: int, weights: List[int]) -> int:
    return value(max_config(k, n), weights) - value(min_config(k, n), weights)

# ---------------------------------------------------------------------------
# A few bases for the scan
# ---------------------------------------------------------------------------

def fibonacci(n):
    F = [0]*(n+3); F[1],F[2]=1,2
    for i in range(3,n+3): F[i]=F[i-1]+F[i-2]
    return [F[i+1] for i in range(n)], F[n]

def pell(n):
    P = [0]*(n+3); P[1],P[2]=1,2
    for i in range(3,n+3): P[i]=2*P[i-1]+P[i-2]
    return [P[i+1] for i in range(n)], P[n]

def tribonacci(n):
    T = [0]*(n+4); T[1],T[2],T[3]=1,1,2
    for i in range(4,n+4): T[i]=T[i-1]+T[i-2]+T[i-3]
    return [T[i+1] for i in range(n)], T[n]

def fast(n):
    P = [0]*(n+3); P[1],P[2]=1,1
    for i in range(3,n+3): P[i]=3*P[i-1]+P[i-2]
    return [P[i+1] for i in range(n)], P[n]

# ---------------------------------------------------------------------------
# Scan
# ---------------------------------------------------------------------------

def density_scan(name: str, gen, n: int, step: int = 1):
    weights, last_w = gen(n)
    alpha = weights[-1]/weights[-2]
    print(f"\n{'='*70}")
    print(f"{name}  n={n}  α≈{alpha:.6f}")
    print(f"{'k':>5}  {'ρ':>7}  {'weight(greedy)':>14}  {'exact?':>7}  {'ratio':>12}")
    print("-"*55)

    exact_ks = []
    for k in range(0, n+1, step):
        d = d_of_k(k, n, weights)
        g = greedy(d, weights)
        gk = sum(g)
        ratio = value(g, weights) / last_w
        exact = (gk == k)
        if exact:
            exact_ks.append(k)
        if step > 1 or k % max(1, n//20) == 0 or exact:
            print(f"{k:5d}  {k/n:7.3f}  {gk:14d}  {str(exact):>7}  {ratio:12.8f}")

    print(f"Exact-weight fixed points (k): {exact_ks}")
    return exact_ks

def main():
    print("DENSITY SCAN – looking for self-consistent weights k")
    # Moderate n so that a full scan is feasible
    for name, gen, n in [
        ("Fibonacci",  fibonacci,  120),
        ("Tribonacci", tribonacci, 120),
        ("Pell",       pell,       120),
        ("Fast",       fast,       120),
    ]:
        density_scan(name, gen, n, step=1)

    print("\nDone.")

if __name__ == "__main__":
    main()
