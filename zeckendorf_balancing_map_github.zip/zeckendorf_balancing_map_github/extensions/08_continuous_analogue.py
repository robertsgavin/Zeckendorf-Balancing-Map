#!/usr/bin/env python3
"""
08_continuous_analogue.py
-------------------------
Crude continuous / infinite-string analogue.
We replace the linear-recurrence basis by pure geometric weights
w_i = α^{i} (or a truncated version) and study the same
difference-of-extremal-configurations map on binary strings of length n.
As n grows this approximates a map on the β-shift / symbolic space.

Also reports the theoretical limits α/(α-1) and 1/(α-1) for comparison.
"""

import random
from typing import List

def geometric_weights(n: int, alpha: float) -> List[float]:
    """w_i = alpha^{i}  (i=0..n-1).  We work with floats here."""
    return [alpha**i for i in range(n)]

def value(v: List[int], weights: List[float]) -> float:
    return sum(a*b for a,b in zip(v, weights))

def greedy_float(d: float, weights: List[float]) -> List[int]:
    """Greedy with floating-point weights (largest-first)."""
    n = len(weights)
    v = [0]*n
    for i in range(n-1, -1, -1):
        if weights[i] <= d + 1e-12:          # tiny tolerance
            v[i] = 1
            d -= weights[i]
    return v

def max_config(k, n):
    v = [0]*n
    for i in range(max(0, n-k), n): v[i] = 1
    return v

def min_config(k, n):
    v = [0]*n
    for i in range(min(k, n)): v[i] = 1
    return v

def balancing_map(v, weights):
    k = sum(v)
    d = value(max_config(k, len(v)), weights) - value(min_config(k, len(v)), weights)
    return greedy_float(d, weights)

def iterate(start, weights, max_steps=40):
    v = start[:]
    for s in range(max_steps):
        nxt = balancing_map(v, weights)
        if nxt == v:
            return v, s
        v = nxt
    return v, max_steps

def run_alpha(alpha: float, n_list, num_random=8):
    high = alpha / (alpha - 1)
    low  = 1 / (alpha - 1)
    regime = ">2" if alpha > 2 else "<2"
    print(f"\nα = {alpha:.6f}  ({regime})   theoretical high={high:.8f}  low={low:.8f}")
    for n in n_list:
        weights = geometric_weights(n, alpha)
        # candidate
        k = n//2
        d = value(max_config(k,n), weights) - value(min_config(k,n), weights)
        vc = greedy_float(d, weights)
        rc = value(vc, weights) / weights[-1]

        random.seed(42)
        starts = [[0]*n, [1]*n] + [[random.randint(0,1) for _ in range(n)] for _ in range(num_random)]
        ratios = []
        for s in starts:
            fp, _ = iterate(s, weights)
            ratios.append(value(fp, weights) / weights[-1])
        from collections import Counter
        dom = Counter(round(r, 8) for r in ratios).most_common(1)[0][0]
        print(f"  n={n:4d}  cand={rc:.8f}  dom={dom:.8f}")

def main():
    print("CONTINUOUS / GEOMETRIC ANALOGUE")
    # representative values on both sides of 2
    for alpha in [1.5, 1.6180339887, 1.839, 2.0, 2.414, 3.0, 3.302]:
        run_alpha(alpha, n_list=[30, 60, 120])
    print("\nDone.")

if __name__ == "__main__":
    main()
