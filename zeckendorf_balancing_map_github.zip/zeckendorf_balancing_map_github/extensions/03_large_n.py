#!/usr/bin/env python3
"""
03_large_n.py
-------------
Push selected bases to very large n (up to a few thousand or more)
to watch:
  - disappearance of secondary attractors
  - stabilisation of the last differing bits of the candidate
  - confirmation that ratios stay locked to the theoretical limits

Memory and time grow roughly linearly with n for the greedy step,
so n=5000–10000 is comfortable; n=20000 is already in the original paper.
"""

import random
from typing import List, Tuple, Dict

def value(v, w): return sum(a*b for a,b in zip(v,w))

def greedy(d, weights):
    n = len(weights)
    v = [0]*n
    for i in range(n-1, -1, -1):
        if weights[i] <= d:
            v[i] = 1
            d -= weights[i]
    return v

def max_config(k, n):
    v = [0]*n
    for i in range(max(0,n-k), n): v[i]=1
    return v

def min_config(k, n):
    v = [0]*n
    for i in range(min(k,n)): v[i]=1
    return v

def balancing_map(v, weights):
    k = sum(v)
    d = value(max_config(k, len(v)), weights) - value(min_config(k, len(v)), weights)
    return greedy(d, weights)

def candidate(n, weights):
    k = n//2
    d = value(max_config(k,n), weights) - value(min_config(k,n), weights)
    return greedy(d, weights)

def iterate_to_fp(start, weights, max_steps=100):
    v = start[:]
    for s in range(max_steps):
        nxt = balancing_map(v, weights)
        if nxt == v: return v, s
        v = nxt
    return v, max_steps

# Bases
def fibonacci(n):
    F=[0]*(n+3); F[1],F[2]=1,2
    for i in range(3,n+3): F[i]=F[i-1]+F[i-2]
    return [F[i+1] for i in range(n)], F[n]

def padovan(n):
    P=[0]*(n+4); P[1],P[2],P[3]=1,1,1
    for i in range(4,n+4): P[i]=P[i-2]+P[i-3]
    return [P[i+1] for i in range(n)], P[n]

def pell(n):
    P=[0]*(n+3); P[1],P[2]=1,2
    for i in range(3,n+3): P[i]=2*P[i-1]+P[i-2]
    return [P[i+1] for i in range(n)], P[n]

def tetranacci(n):
    T=[0]*(n+5); T[1],T[2],T[3],T[4]=1,1,2,4
    for i in range(5,n+5): T[i]=T[i-1]+T[i-2]+T[i-3]+T[i-4]
    return [T[i+1] for i in range(n)], T[n]

def run_large(name, gen, n_values, num_random=6):
    print(f"\n{'='*70}\n{name}\n{'='*70}")
    for n in n_values:
        weights, last = gen(n)
        alpha = weights[-1]/weights[-2]
        high = alpha/(alpha-1)
        low  = 1/(alpha-1)

        vc = candidate(n, weights)
        rc = value(vc, weights)/last
        exact = balancing_map(vc, weights) == vc

        # a few random starts
        random.seed(42)
        starts = [[0]*n, [1]*n]
        for _ in range(num_random):
            starts.append([random.randint(0,1) for _ in range(n)])
        ratios = []
        for s in starts:
            fp, steps = iterate_to_fp(s, weights)
            ratios.append(value(fp, weights)/last)

        from collections import Counter
        cnt = Counter(round(r,12) for r in ratios)   # group by rounded ratio
        print(f"n={n:5d}  α≈{alpha:.6f}  cand={rc:.12f} exact={exact}  "
              f"dom_ratios={dict(cnt)}  (theor high={high:.8f} low={low:.8f})")

def main():
    # Keep the largest n moderate so the script finishes in reasonable time
    n_values = [500, 1000, 2000, 5000]
    for name, gen in [
        ("Fibonacci",  fibonacci),
        ("Padovan",    padovan),
        ("Pell",       pell),
        ("Tetranacci", tetranacci),
    ]:
        run_large(name, gen, n_values)
    print("\nDone.")

if __name__ == "__main__":
    main()
