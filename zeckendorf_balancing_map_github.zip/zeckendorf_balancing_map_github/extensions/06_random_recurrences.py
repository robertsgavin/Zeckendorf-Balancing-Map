#!/usr/bin/env python3
"""
06_random_recurrences.py  (fixed)
------------------------
Sample random coefficient vectors for small order, keep only those that
produce a strictly increasing positive sequence with a simple dominant
root α > 1, then run the balancing map and record the observed regime
and attractor ratios.

Gives a statistical picture of how often the α<2 / α>2 dichotomy appears.

FIX (this version): generate_sequence() previously only checked that
*recurrence-generated* terms were strictly increasing (the loop started
at i = r+1), so a non-monotonic block of seed values could slip through
uncaught -- e.g. coeffs=[0,2,0,3], init=[1,2,1,1] produced the sequence
1, 2, 1, 1, 5, 8, 13, ... and was accepted as valid despite dropping from
2 to 1. The seed values are now checked for strict monotonicity as well,
so any such case is correctly rejected before the recurrence even runs.
"""

import random
import math
from typing import List, Tuple, Optional

def value(v, w): return sum(a*b for a,b in zip(v,w))

def greedy(d, weights):
    n = len(weights)
    v = [0]*n
    for i in range(n-1, -1, -1):
        if weights[i] <= d:
            v[i] = 1
            d -= weights[i]
    return v

def max_config(k, n):
    v = [0]*n
    for i in range(max(0, n-k), n): v[i] = 1
    return v

def min_config(k, n):
    v = [0]*n
    for i in range(min(k, n)): v[i] = 1
    return v

def balancing_map(v, weights):
    k = sum(v)
    d = value(max_config(k, len(v)), weights) - value(min_config(k, len(v)), weights)
    return greedy(d, weights)

def iterate(start, weights, max_steps=50):
    v = start[:]
    for s in range(max_steps):
        nxt = balancing_map(v, weights)
        if nxt == v: return v, s
        v = nxt
    return v, max_steps

def generate_sequence(coeffs: List[int], init: List[int], n: int) -> Optional[List[int]]:
    r = len(coeffs)

    # --- FIX: validate the seed block itself before running the recurrence.
    # The old code loaded init[0..r-1] into G[1..r] with no check, and its
    # monotonicity test only started comparing from G[r+1] vs G[r] onward,
    # so a non-increasing seed (e.g. [1,2,1,1]) was silently accepted.
    for i in range(1, r):
        if init[i] <= init[i-1]:
            return None

    G = [0]*(n + r + 1)
    for i in range(r):
        G[i+1] = init[i]
    for i in range(r+1, n+r+1):
        G[i] = sum(coeffs[j] * G[i-1-j] for j in range(r))
        if G[i] <= G[i-1]:          # not strictly increasing
            return None
    return [G[i+1] for i in range(n)]

def random_coeffs(order: int, max_c: int = 4) -> List[int]:
    """Random non-negative coefficients, not all zero."""
    while True:
        c = [random.randint(0, max_c) for _ in range(order)]
        if sum(c) > 0:
            return c

def estimate_alpha(weights: List[int]) -> float:
    return weights[-1] / weights[-2]

def run_sample(order: int, n: int = 80, trials: int = 40, seed: int = 123):
    random.seed(seed)
    print(f"\nOrder-{order} random recurrences  (n={n}, {trials} trials)")
    print(f"{'coeffs':<20}  {'α':>8}  {'regime':>6}  {'cand_ratio':>12}  {'dom_ratio':>12}")

    success = 0
    for t in range(trials):
        coeffs = random_coeffs(order)
        # simple positive initial conditions
        init = [1] + [random.randint(1, 3) for _ in range(order-1)]
        weights = generate_sequence(coeffs, init, n)
        if weights is None:
            continue
        success += 1
        alpha = estimate_alpha(weights)
        regime = ">2" if alpha > 2 else "<2"
        high = alpha/(alpha-1)
        low  = 1/(alpha-1)

        # candidate
        k = n//2
        d = value(max_config(k,n), weights) - value(min_config(k,n), weights)
        vc = greedy(d, weights)
        rc = value(vc, weights) / weights[-1]

        # a couple of random starts
        ratios = []
        for _ in range(4):
            s = [random.randint(0,1) for _ in range(n)]
            fp, _ = iterate(s, weights)
            ratios.append(value(fp, weights)/weights[-1])
        dom = max(set(round(r,8) for r in ratios), key=lambda x: ratios.count(x))

        print(f"{str(coeffs):<20}  {alpha:8.4f}  {regime:>6}  {rc:12.8f}  {dom:12.8f}")

    print(f"Successful positive increasing sequences: {success}/{trials}")

def main():
    for order in [2, 3, 4]:
        run_sample(order, n=60, trials=30)
    print("\nDone.")

if __name__ == "__main__":
    main()
