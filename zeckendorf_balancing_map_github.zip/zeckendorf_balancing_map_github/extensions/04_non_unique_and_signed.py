#!/usr/bin/env python3
"""
04_non_unique_and_signed.py
---------------------------
Explore bases that may violate uniqueness of the greedy expansion
(classic ZLRS examples) and a few sequences with negative coefficients
that nevertheless stay positive and strictly increasing.

The balancing map is still well-defined; we simply watch whether
the attractor picture survives.
"""

import random
from typing import List, Tuple

def value(v, w): return sum(a*b for a,b in zip(v,w))

def greedy(d, weights):
    n = len(weights)
    v = [0]*n
    for i in range(n-1,-1,-1):
        if weights[i] <= d:
            v[i] = 1
            d -= weights[i]
    return v

def max_config(k,n):
    v=[0]*n
    for i in range(max(0,n-k),n): v[i]=1
    return v

def min_config(k,n):
    v=[0]*n
    for i in range(min(k,n)): v[i]=1
    return v

def balancing_map(v, weights):
    k = sum(v)
    d = value(max_config(k,len(v)),weights) - value(min_config(k,len(v)),weights)
    return greedy(d, weights)

def candidate(n, weights):
    k = n//2
    d = value(max_config(k,n),weights) - value(min_config(k,n),weights)
    return greedy(d, weights)

def iterate(start, weights, max_steps=60):
    v = start[:]
    for s in range(max_steps):
        nxt = balancing_map(v, weights)
        if nxt == v: return v, s
        v = nxt
    return v, max_steps

# ---------------------------------------------------------------------------
# Bases that can lose uniqueness or have negative coefficients
# ---------------------------------------------------------------------------

def padovan(n):   # classic ZLRS – already known to have secondary attractors at moderate n
    P=[0]*(n+4); P[1],P[2],P[3]=1,1,1
    for i in range(4,n+4): P[i]=P[i-2]+P[i-3]
    return [P[i+1] for i in range(n)], P[n]

def signed_order2(n):
    """G_i = 3 G_{i-1} - G_{i-2}  (positive for these init conditions)."""
    G=[0]*(n+3); G[1],G[2]=1,3
    for i in range(3,n+3):
        G[i] = 3*G[i-1] - G[i-2]
    return [G[i+1] for i in range(n)], G[n]

def signed_order3(n):
    """G_i = G_{i-1} + G_{i-2} - G_{i-3}  (careful with initial conditions)."""
    G=[0]*(n+4); G[1],G[2],G[3]=1,2,2
    for i in range(4,n+4):
        G[i] = G[i-1] + G[i-2] - G[i-3]
        if G[i] <= 0:          # abort if positivity fails
            return None, None
    return [G[i+1] for i in range(n)], G[n]

def slow_zlrs(n):
    """Another sparse recurrence that can produce non-unique expansions."""
    G=[0]*(n+4); G[1],G[2],G[3]=1,1,1
    for i in range(4,n+4):
        G[i] = G[i-1] + G[i-3]
    return [G[i+1] for i in range(n)], G[n]

def run(name, gen, n_list, num_random=8):
    print(f"\n{'='*70}\n{name}\n{'='*70}")
    for n in n_list:
        res = gen(n)
        if res[0] is None:
            print(f"n={n}: positivity failed – skipped")
            continue
        weights, last = res
        if any(w <= 0 for w in weights):
            print(f"n={n}: non-positive term – skipped")
            continue
        alpha = weights[-1]/weights[-2]
        vc = candidate(n, weights)
        rc = value(vc, weights)/last
        exact = balancing_map(vc, weights) == vc

        random.seed(1)
        starts = [[0]*n, [1]*n] + [[random.randint(0,1) for _ in range(n)] for _ in range(num_random)]
        ratios = []
        for s in starts:
            fp, _ = iterate(s, weights)
            ratios.append(round(value(fp, weights)/last, 12))
        from collections import Counter
        print(f"n={n:4d} α≈{alpha:.6f} cand={rc:.10f} exact={exact} "
              f"observed_ratios={dict(Counter(ratios))}")

def main():
    n_list = [30, 50, 100, 200, 400]
    for name, gen in [
        ("Padovan (ZLRS)",          padovan),
        ("Slow ZLRS (x_n=x_{n-1}+x_{n-3})", slow_zlrs),
        ("Signed 3x_{n-1}-x_{n-2}", signed_order2),
        ("Signed x_{n-1}+x_{n-2}-x_{n-3}", signed_order3),
    ]:
        run(name, gen, n_list)
    print("\nDone.")

if __name__ == "__main__":
    main()
