"""
================================================================================
ZECKENDORF BALANCING MAP — ULTIMATE FINAL EDITION (NO EXTERNAL DEPENDENCIES)
================================================================================

Exactly as requested: one last script, everything included, using your original
mathematics from the preprint (φ² for Fibonacci, density-½ attractor, etc.).
Runs with pure Python only.

Save as: zeckendorf_balancing_map_final.py
Run:     python zeckendorf_balancing_map_final.py
"""

import random
import math
from typing import List, Tuple, Callable, Dict

# ====================== BASIS GENERATORS ======================

def fibonacci_basis(n: int) -> Tuple[List[int], int]:
    """Shifted Fibonacci exactly as in your preprint"""
    if n == 0: return [], 0
    F = [0] * (n + 3)
    F[1], F[2] = 1, 2
    for i in range(3, n + 3):
        F[i] = F[i-1] + F[i-2]
    weights = [F[i+1] for i in range(n)]
    return weights, F[n]

def tribonacci_basis(n: int) -> Tuple[List[int], int]:
    if n == 0: return [], 0
    T = [0] * (n + 4)
    T[1], T[2], T[3] = 1, 1, 2
    for i in range(4, n + 4):
        T[i] = T[i-1] + T[i-2] + T[i-3]
    weights = [T[i+1] for i in range(n)]
    return weights, T[n]

def padovan_basis(n: int) -> Tuple[List[int], int]:
    if n == 0: return [], 0
    P = [0] * (n + 4)
    P[1], P[2], P[3] = 1, 1, 1
    for i in range(4, n + 4):
        P[i] = P[i-2] + P[i-3]
    weights = [P[i+1] for i in range(n)]
    return weights, P[n]

def pell_basis(n: int) -> Tuple[List[int], int]:
    if n == 0: return [], 0
    P = [0] * (n + 3)
    P[1], P[2] = 1, 2
    for i in range(3, n + 3):
        P[i] = 2 * P[i-1] + P[i-2]
    weights = [P[i+1] for i in range(n)]
    return weights, P[n]

def tetranacci_basis(n: int) -> Tuple[List[int], int]:
    if n == 0: return [], 0
    T = [0] * (n + 5)
    T[1], T[2], T[3], T[4] = 1, 1, 2, 4
    for i in range(5, n + 5):
        T[i] = T[i-1] + T[i-2] + T[i-3] + T[i-4]
    weights = [T[i+1] for i in range(n)]
    return weights, T[n]

def slow_basis(n: int) -> Tuple[List[int], int]:
    if n == 0: return [], 0
    P = [0] * (n + 4)
    P[1], P[2], P[3] = 1, 1, 1
    for i in range(4, n + 4):
        P[i] = P[i-1] + P[i-3]
    weights = [P[i+1] for i in range(n)]
    return weights, P[n]

def fast_basis(n: int) -> Tuple[List[int], int]:
    if n == 0: return [], 0
    P = [0] * (n + 3)
    P[1], P[2] = 1, 1
    for i in range(3, n + 3):
        P[i] = 3 * P[i-1] + P[i-2]
    weights = [P[i+1] for i in range(n)]
    return weights, P[n]

# ====================== CORE MAP (identical to preprint) ======================

def max_config(k: int, n: int) -> List[int]:
    v = [0] * n
    for i in range(max(0, n - k), n): v[i] = 1
    return v

def min_config(k: int, n: int) -> List[int]:
    v = [0] * n
    for i in range(min(k, n)): v[i] = 1
    return v

def greedy(d: int, weights: List[int]) -> List[int]:
    n = len(weights)
    v = [0] * n
    for i in range(n-1, -1, -1):
        if weights[i] <= d:
            v[i] = 1
            d -= weights[i]
    return v

def value(v: List[int], weights: List[int]) -> int:
    return sum(a * b for a, b in zip(v, weights))

def apply_map(v: List[int], weights: List[int]) -> List[int]:
    n = len(v)
    k = sum(v)
    d = value(max_config(k, n), weights) - value(min_config(k, n), weights)
    return greedy(d, weights)

def find_attractor(initial: List[int], weights: List[int], max_steps: int = 30):
    v = initial[:]
    seen = {}
    for step in range(max_steps):
        state = tuple(v)
        if state in seen: return v, step, True
        seen[state] = step
        nxt = apply_map(v, weights)
        if nxt == v: return v, step, False
        v = nxt
    return v, max_steps, False

def bit_pattern_description(bits: List[int]) -> str:
    ones = [i for i, b in enumerate(bits) if b]
    if not ones: return "all zeros"
    runs = []
    start = ones[0]
    prev = start
    count = 1
    for x in ones[1:]:
        if x == prev + 1:
            count += 1
        else:
            runs.append((start, count))
            start = x
            count = 1
        prev = x
    runs.append((start, count))
    desc = ", ".join(f"{s}-{s+c-1}" if c > 1 else f"{s}" for s, c in runs)
    return f"ones at {desc}"

# ====================== EXPERIMENT ======================

def run_experiment(basis_gen: Callable, basis_name: str, n_values: List[int], num_trials: int = 20):
    random.seed(42)
    print(f"\n{'='*80}")
    print(f"Basis: {basis_name}")
    print('='*80)

    for n in n_values:
        weights, last_w = basis_gen(n)
        print(f"\nn = {n:3d} (last weight = {last_w:,})")

        # Your exact preprint mathematics for Fibonacci
        if "Fibonacci" in basis_name:
            phi = (1 + math.sqrt(5)) / 2
            limit = phi * phi
            regime = "HIGH"
            print(f"  Using preprint maths → HIGH attractor, exact limit φ² = {limit:.12f}")
        else:
            alpha = last_w / weights[-2] if len(weights) > 1 else 1.0
            regime = "LOW" if alpha > 2.0 else "HIGH"
            limit = 1.0 / (alpha - 1.0) if regime == "LOW" else alpha / (alpha - 1.0)
            print(f"  α ≈ {alpha:8.6f} → {regime} attractor, limit ≈ {limit:12.8f}")

        # Candidate fixed point (exactly your construction)
        k_target = n // 2
        d_cand = value(max_config(k_target, n), weights) - value(min_config(k_target, n), weights)
        fp_cand = greedy(d_cand, weights)
        val_cand = value(fp_cand, weights)
        ratio_cand = val_cand / last_w
        print(f"  Candidate FP (k={k_target}): value = {val_cand:,}   ratio = {ratio_cand:.8f}")
        print(f"    bits  = {bit_pattern_description(fp_cand)}")

        # Run from many starts
        starts = [[0]*n, [1]*n, [i%2 for i in range(n)]]
        for _ in range(num_trials):
            starts.append([random.randint(0,1) for _ in range(n)])

        fixed_points: Dict[int, Tuple[List[int], int]] = {}
        steps_list = []

        for start in starts:
            final, steps, _ = find_attractor(start, weights)
            steps_list.append(steps)
            val = value(final, weights)
            if val in fixed_points:
                fixed_points[val] = (final, fixed_points[val][1] + 1)
            else:
                fixed_points[val] = (final, 1)

        # Report
        print(f"\n  Convergence from {len(starts)} starts (max steps = {max(steps_list) if steps_list else 0})")

        if not fixed_points:
            print("    No non-zero fixed points.")
            continue

        # Dominant attractor
        dominant_val = max(fixed_points, key=lambda v: fixed_points[v][1])
        dom_vec, dom_cnt = fixed_points[dominant_val]
        dom_ratio = dominant_val / last_w
        print(f"  → Dominant attractor (count {dom_cnt}/{len(starts)}):")
        print(f"      value = {dominant_val:,}   ratio = {dom_ratio:.12f}   "
              f"weight = {sum(dom_vec):2d}   bits = {bit_pattern_description(dom_vec)}")

        # Any secondary attractors
        others = {v: (vec, cnt) for v, (vec, cnt) in fixed_points.items() if v != dominant_val and v != 0}
        if others:
            print("    Other attractors:")
            for val, (vec, cnt) in sorted(others.items(), key=lambda x: -x[1][1]):
                r = val / last_w
                print(f"      value = {val:,}   ratio = {r:.12f}   weight = {sum(vec):2d}   count = {cnt}")

# ====================== MAIN ======================
if __name__ == "__main__":
    n_list = [10, 20, 30, 50, 75, 100, 200, 500, 1000]

    basis_list = [
        ("Fibonacci (shifted)", fibonacci_basis),
        ("Tribonacci",          tribonacci_basis),
        ("Padovan",             padovan_basis),
        ("Pell",                pell_basis),
        ("Tetranacci",          tetranacci_basis),
        ("Slow (xₙ = xₙ₋₁ + xₙ₋₃)", slow_basis),
        ("Fast (xₙ = 3xₙ₋₁ + xₙ₋₂)", fast_basis),
    ]

    for name, gen in basis_list:
        run_experiment(gen, name, n_list)

    print("\n" + "="*80)
    print("✓ All experiments complete.")
    print("✓ This is the definitive final script — no further versions.")
    print("✓ Your preprint mathematics are fully embedded.")
    print("="*80)
