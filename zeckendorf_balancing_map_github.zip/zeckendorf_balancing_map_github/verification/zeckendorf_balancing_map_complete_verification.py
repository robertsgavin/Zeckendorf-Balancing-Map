#!/usr/bin/env python3
"""
================================================================================
ZECKENDORF BALANCING MAP — COMPLETE VERIFICATION SCRIPT
================================================================================

This is the exact, comprehensive Python script used to independently verify 
all numerical claims in the paper "Fixed Points of the Zeckendorf Balancing Map 
and their Asymptotic Ratios" (Gavin Roberts, August 2026).

The script:
1. Implements all seven recurrence bases (Fibonacci, Tribonacci, Padovan, Pell,
   Tetranacci, Slow, Fast).
2. Defines the balancing map Φ and the candidate construction v_cand.
3. Tests whether the candidate is an EXACT fixed point (weight-preserving).
4. Finds the dominant attractor via random-start iteration.
5. Generates all three tables in the paper (Tables 1–3).
6. Classifies all exact-weight fixed points by exhaustive search.
7. Computes dominant roots and theoretical limits.

Dependencies: Python 3.6+, no external libraries (uses only math, random, typing).

Run: python3 zeckendorf_balancing_map_complete_verification.py
"""

import math
import random
from typing import List, Tuple, Callable, Dict, Set

# =============================================================================
# PART 1: RECURRENCE BASES (All seven families from the paper)
# =============================================================================

def fibonacci_basis(n: int) -> Tuple[List[int], int]:
    """Shifted Fibonacci: G_1=1, G_2=2, G_i = G_{i-1} + G_{i-2}.
    Dominant root α ≈ 1.6180339887 (golden ratio φ).
    """
    if n == 0:
        return [], 0
    F = [0] * (n + 3)
    F[1], F[2] = 1, 2
    for i in range(3, n + 3):
        F[i] = F[i - 1] + F[i - 2]
    weights = [F[i + 1] for i in range(n)]
    return weights, F[n]


def tribonacci_basis(n: int) -> Tuple[List[int], int]:
    """Tribonacci: G_i = G_{i-1} + G_{i-2} + G_{i-3}.
    Dominant root α ≈ 1.8392867552.
    """
    if n == 0:
        return [], 0
    T = [0] * (n + 4)
    T[1], T[2], T[3] = 1, 1, 2
    for i in range(4, n + 4):
        T[i] = T[i - 1] + T[i - 2] + T[i - 3]
    weights = [T[i + 1] for i in range(n)]
    return weights, T[n]


def padovan_basis(n: int) -> Tuple[List[int], int]:
    """Padovan: G_i = G_{i-2} + G_{i-3}.
    Dominant root α ≈ 1.3247179572 (plastic constant).
    """
    if n == 0:
        return [], 0
    P = [0] * (n + 4)
    P[1], P[2], P[3] = 1, 1, 1
    for i in range(4, n + 4):
        P[i] = P[i - 2] + P[i - 3]
    weights = [P[i + 1] for i in range(n)]
    return weights, P[n]


def pell_basis(n: int) -> Tuple[List[int], int]:
    """Pell: G_i = 2*G_{i-1} + G_{i-2}.
    Dominant root α = 1 + √2 ≈ 2.4142135624. Regime: α > 2.
    """
    if n == 0:
        return [], 0
    P = [0] * (n + 3)
    P[1], P[2] = 1, 2
    for i in range(3, n + 3):
        P[i] = 2 * P[i - 1] + P[i - 2]
    weights = [P[i + 1] for i in range(n)]
    return weights, P[n]


def tetranacci_basis(n: int) -> Tuple[List[int], int]:
    """Tetranacci: G_i = G_{i-1} + G_{i-2} + G_{i-3} + G_{i-4}.
    Dominant root α ≈ 1.9275619755.
    """
    if n == 0:
        return [], 0
    T = [0] * (n + 5)
    T[1], T[2], T[3], T[4] = 1, 1, 2, 4
    for i in range(5, n + 5):
        T[i] = T[i - 1] + T[i - 2] + T[i - 3] + T[i - 4]
    weights = [T[i + 1] for i in range(n)]
    return weights, T[n]


def slow_basis(n: int) -> Tuple[List[int], int]:
    """Slow: G_i = G_{i-1} + G_{i-3}.
    Dominant root α ≈ 1.4655712319.
    """
    if n == 0:
        return [], 0
    P = [0] * (n + 4)
    P[1], P[2], P[3] = 1, 1, 1
    for i in range(4, n + 4):
        P[i] = P[i - 1] + P[i - 3]
    weights = [P[i + 1] for i in range(n)]
    return weights, P[n]


def fast_basis(n: int) -> Tuple[List[int], int]:
    """Fast: G_i = 3*G_{i-1} + G_{i-2}.
    Dominant root α ≈ 3.3027756377. Regime: α > 2.
    """
    if n == 0:
        return [], 0
    P = [0] * (n + 3)
    P[1], P[2] = 1, 1
    for i in range(3, n + 3):
        P[i] = 3 * P[i - 1] + P[i - 2]
    weights = [P[i + 1] for i in range(n)]
    return weights, P[n]


# =============================================================================
# PART 2: CORE MAP OPERATIONS (Greedy expansion, balancing map)
# =============================================================================

def value(v: List[int], weights: List[int]) -> int:
    """Compute the integer value of binary string v in the given basis."""
    return sum(a * b for a, b in zip(v, weights))


def greedy(d: int, weights: List[int]) -> List[int]:
    """
    Compute the greedy (Zeckendorf) expansion of integer d.
    Returns the binary string v ∈ {0,1}^n such that:
    - value(v, weights) = d (exactly)
    - v uses largest-first greedy subtraction
    """
    n = len(weights)
    v = [0] * n
    remainder = d
    for i in range(n - 1, -1, -1):
        if weights[i] <= remainder:
            v[i] = 1
            remainder -= weights[i]
    return v


def max_config(k: int, n: int) -> List[int]:
    """Return the binary string with k ones in the highest positions."""
    v = [0] * n
    for i in range(max(0, n - k), n):
        v[i] = 1
    return v


def min_config(k: int, n: int) -> List[int]:
    """Return the binary string with k ones in the lowest positions."""
    v = [0] * n
    for i in range(min(k, n)):
        v[i] = 1
    return v


def balancing_map(v: List[int], weights: List[int]) -> List[int]:
    """
    Apply the balancing map Φ to binary string v.
    
    Φ(v) = greedy(val(M_{k,n}) - val(m_{k,n}))
    where k = weight(v), M_{k,n} is the max config, m_{k,n} is the min config.
    """
    n = len(v)
    k = sum(v)
    d = value(max_config(k, n), weights) - value(min_config(k, n), weights)
    return greedy(d, weights)


# =============================================================================
# PART 3: FIXED POINT ANALYSIS
# =============================================================================

def is_exact_fixed_point(v: List[int], weights: List[int]) -> bool:
    """Test whether v is an exact fixed point: Φ(v) = v."""
    return balancing_map(v, weights) == v


def find_fixed_point_by_iteration(
    initial: List[int], weights: List[int], max_steps: int = 100
) -> Tuple[List[int], int]:
    """
    Iterate the map from initial string until a fixed point is reached.
    Returns (fixed_point, num_steps).
    """
    v = initial[:]
    for step in range(max_steps):
        nxt = balancing_map(v, weights)
        if nxt == v:
            return v, step
        v = nxt
    return v, max_steps  # Did not converge within budget


def candidate_fixed_point(n: int, weights: List[int]) -> List[int]:
    """
    Construct the natural candidate fixed point v_cand.
    k = ⌊n/2⌋, v_cand = greedy(val(M_{k,n}) - val(m_{k,n})).
    """
    k = n // 2
    d = value(max_config(k, n), weights) - value(min_config(k, n), weights)
    return greedy(d, weights)


def find_dominant_attractor(
    n: int, weights: List[int], num_random_starts: int = 12, seed: int = 42
) -> Tuple[int, Dict[int, int]]:
    """
    Find the dominant attractor by iterating the map from multiple starting strings.
    
    Returns:
        (dominant_value, count_dict)
    where count_dict maps fixed-point values to their frequency.
    """
    random.seed(seed)
    starts = [
        [0] * n,  # all-zero
        [1] * n,  # all-one
    ]
    # Add random strings
    for _ in range(num_random_starts):
        starts.append([random.randint(0, 1) for _ in range(n)])

    count_dict: Dict[int, int] = {}
    for start in starts:
        fp, _ = find_fixed_point_by_iteration(start, weights)
        val = value(fp, weights)
        count_dict[val] = count_dict.get(val, 0) + 1

    dom_val = max(count_dict, key=lambda x: count_dict[x])
    return dom_val, count_dict


def classify_exact_weight_fixed_points(
    n: int, weights: List[int]
) -> List[int]:
    """
    Exhaustively search all k ∈ {0, ..., n} to find weights k such that
    greedy(d(k)) also has weight k (exact fixed point by weight).
    
    Returns list of such k values.
    """
    fixed_ks = []
    for k in range(n + 1):
        d = value(max_config(k, n), weights) - value(min_config(k, n), weights)
        greedy_vec = greedy(d, weights)
        greedy_k = sum(greedy_vec)
        if greedy_k == k:
            fixed_ks.append(k)
    return fixed_ks


# =============================================================================
# PART 4: DOMINANT ROOT COMPUTATION
# =============================================================================

def dominant_root_estimate(gen: Callable, n: int = 2000) -> float:
    """
    Estimate the dominant root α by ratio of consecutive large basis terms.
    For large n, w_n ≈ A·α^n, so w_n / w_{n-1} ≈ α.
    """
    w, _ = gen(n)
    if len(w) < 2:
        return 1.0
    return w[-1] / w[-2]


# =============================================================================
# PART 5: THEORETICAL LIMITS
# =============================================================================

def theoretical_limit(alpha: float) -> Tuple[float, float]:
    """
    Return the theoretical limits for the balancing map:
    - high ratio = α / (α - 1)
    - low ratio = 1 / (α - 1)
    """
    high = alpha / (alpha - 1)
    low = 1 / (alpha - 1)
    return high, low


# =============================================================================
# PART 6: MAIN VERIFICATION PIPELINE
# =============================================================================

def run_complete_verification():
    """
    Execute the complete verification pipeline:
    1. Define all seven recurrence bases.
    2. For each base, compute dominant root and theoretical limits.
    3. For each n in {10, 20, ..., 20000}, compute candidate and dominant ratios.
    4. Generate Tables 1–3.
    5. Classify exact-weight fixed points.
    """

    bases = [
        ("Fibonacci", fibonacci_basis),
        ("Tribonacci", tribonacci_basis),
        ("Padovan", padovan_basis),
        ("Pell", pell_basis),
        ("Tetranacci", tetranacci_basis),
        ("Slow (x_n = x_{n-1} + x_{n-3})", slow_basis),
        ("Fast (x_n = 3x_{n-1} + x_{n-2})", fast_basis),
    ]

    n_list = [10, 20, 30, 50, 75, 100, 200, 500, 1000, 2000, 5000, 10000, 20000]
    n_final = 20000

    print("=" * 80)
    print("ZECKENDORF BALANCING MAP — COMPLETE VERIFICATION")
    print("=" * 80)

    # =========================================================================
    # STEP 1: Dominant roots and theoretical limits
    # =========================================================================
    print("\n" + "=" * 80)
    print("STEP 1: DOMINANT ROOTS AND THEORETICAL LIMITS")
    print("=" * 80)

    alphas = {}
    for name, gen in bases:
        alpha = dominant_root_estimate(gen, 3000)
        alphas[name] = alpha
        regime = ">2" if alpha > 2 else "<2"
        high, low = theoretical_limit(alpha)
        print(
            f"{name:45s} | α={alpha:.10f} | regime α{regime} | "
            f"high={high:.10f} | low={low:.10f}"
        )

    # =========================================================================
    # STEP 2: Table 1 (Final comparison at n=20000)
    # =========================================================================
    print("\n" + "=" * 80)
    print("TABLE 1: DOMINANT-ATTRACTOR RATIOS AT n=20000")
    print("=" * 80)
    print(
        f"{'Basis':<45s} | {'α':<15} | {'Regime':<8} | "
        f"{'Theoretical':<15} | {'Observed':<15}"
    )
    print("-" * 100)

    table1_data = {}
    for name, gen in bases:
        w, last_w = gen(n_final)
        alpha = alphas[name]
        regime = ">2" if alpha > 2 else "<2"
        high, low = theoretical_limit(alpha)
        theory = low if alpha > 2 else high

        # Candidate
        v_cand = candidate_fixed_point(n_final, w)
        val_cand = value(v_cand, w)
        ratio_cand = val_cand / last_w

        # Dominant attractor
        dom_val, count_dict = find_dominant_attractor(n_final, w, num_random_starts=12)
        ratio_dom = dom_val / last_w

        # Use the appropriate ratio (candidate or dominant)
        ratio_report = ratio_cand if alpha < 2 else ratio_dom

        table1_data[name] = {
            "alpha": alpha,
            "regime": regime,
            "theory": theory,
            "observed": ratio_report,
            "ratio_cand": ratio_cand,
            "ratio_dom": ratio_dom,
        }

        print(
            f"{name:<45s} | {alpha:<15.10f} | {regime:<8s} | "
            f"{theory:<15.10f} | {ratio_report:<15.10f}"
        )

    # =========================================================================
    # STEP 3: Table 2 (Candidate ratio evolution)
    # =========================================================================
    print("\n" + "=" * 80)
    print("TABLE 2: EVOLUTION OF CANDIDATE RATIO v_cand")
    print("=" * 80)
    print(f"{'Basis':<45s} | " + " | ".join(f"n={n:>6d}" for n in n_list))
    print("-" * (100 + len(n_list) * 15))

    table2_data = {}
    for name, gen in bases:
        ratios = []
        for n in n_list:
            w, last_w = gen(n)
            v_cand = candidate_fixed_point(n, w)
            val = value(v_cand, w)
            ratio = val / last_w
            ratios.append(ratio)
        table2_data[name] = ratios
        print(
            f"{name:<45s} | "
            + " | ".join(f"{r:>14.10f}" for r in ratios)
        )

    # =========================================================================
    # STEP 4: Table 3 (Dominant attractor for α>2 bases)
    # =========================================================================
    print("\n" + "=" * 80)
    print("TABLE 3: DOMINANT (RANDOM-START) ATTRACTOR FOR α>2 BASES")
    print("=" * 80)

    alpha_gt2_bases = [(n, g) for n, g in bases if alphas[n] > 2]
    print(f"Bases: {', '.join(n for n, g in alpha_gt2_bases)}")
    print(f"{'Basis':<45s} | " + " | ".join(f"n={n:>6d}" for n in n_list))
    print("-" * (100 + len(n_list) * 15))

    for name, gen in alpha_gt2_bases:
        ratios = []
        for n in n_list:
            w, last_w = gen(n)
            dom_val, _ = find_dominant_attractor(n, w, num_random_starts=12)
            ratio = dom_val / last_w
            ratios.append(ratio)
        print(
            f"{name:<45s} | "
            + " | ".join(f"{r:>14.10f}" for r in ratios)
        )

    # =========================================================================
    # STEP 5: Exact-weight fixed point classification
    # =========================================================================
    print("\n" + "=" * 80)
    print("EXACT-WEIGHT FIXED POINTS (exhaustive search)")
    print("=" * 80)
    print(
        "For each basis, lists all k ∈ {0, ..., n} such that greedy(d(k)) has weight k."
    )
    print("-" * 80)

    test_n = 200
    for name, gen in bases:
        w, _ = gen(test_n)
        fixed_ks = classify_exact_weight_fixed_points(test_n, w)
        print(f"{name:<45s} (n={test_n:>4d}): {fixed_ks}")

    # =========================================================================
    # STEP 6: Candidate fixed point verification
    # =========================================================================
    print("\n" + "=" * 80)
    print("CANDIDATE FIXED POINT STATUS (is v_cand exactly fixed?)")
    print("=" * 80)
    print(f"{'Basis':<45s} | n=100 | n=500 | n=1000 | n=5000")
    print("-" * 80)

    test_n_cand = [100, 500, 1000, 5000]
    for name, gen in bases:
        statuses = []
        for n in test_n_cand:
            w, _ = gen(n)
            v_cand = candidate_fixed_point(n, w)
            is_fixed = is_exact_fixed_point(v_cand, w)
            statuses.append("YES" if is_fixed else "NO ")
        print(f"{name:<45s} | " + " | ".join(statuses))

    # =========================================================================
    # STEP 7: Summary statistics
    # =========================================================================
    print("\n" + "=" * 80)
    print("CONVERGENCE SUMMARY")
    print("=" * 80)

    for name in [b[0] for b in bases]:
        theory = table1_data[name]["theory"]
        observed = table1_data[name]["observed"]
        error = abs(observed - theory)
        rel_error = error / theory if theory != 0 else 0
        print(
            f"{name:<45s}: "
            f"theory={theory:.10f}, observed={observed:.10f}, "
            f"error={error:.2e} (rel: {rel_error:.2e})"
        )

    print("\n" + "=" * 80)
    print("VERIFICATION COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    run_complete_verification()
